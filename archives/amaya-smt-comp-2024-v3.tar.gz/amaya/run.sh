#!/usr/bin/bash
AMAYA_DIR_PATH=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
# echo "Using amaya location: ${AMAYA_DIR_PATH}"
LD_LIBRARY_PATH="$LD_LIBRARY_PATH:${AMAYA_DIR_PATH}/venv/lib" ${AMAYA_DIR_PATH}/venv/bin/python3 ${AMAYA_DIR_PATH}/run-amaya.py --fast -O all get-sat $1
