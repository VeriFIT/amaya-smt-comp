# Directory with formulae for benchmarking

The formulae are obtained from [StarExec](https://www.starexec.org/starexec/secure/explore/spaces.jsp?id=405288).
