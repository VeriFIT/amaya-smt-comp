#!/usr/bin/bash
LD_LIBRARY_PATH="$LD_LIBRARY_PATH:./venv/lib" ./venv/bin/python3 run-amaya.py --fast -O all get-sat $1
